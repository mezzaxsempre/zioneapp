// Array contenente i file audio disponibili per la riproduzione casuale
const audioFiles = [
    'audio1.ogg',
    'audio2.ogg',
    'audio3.ogg',
    'audio4.ogg',
    'audio5.ogg',
    'audio6.ogg',
    'audio7.ogg',
    'audio8.ogg',
    'audio9.ogg',
    // Add other audio files similarly
    'audio75.ogg',
    'audio76.ogg'
];

// Funzione per riprodurre il bonus track
function playBonusTrack() {
    const bonusAudio = new Audio('bonus_track.ogg');
    bonusAudio.play();
}

// Event listener per il pulsante "Invia"
document.getElementById('send-button').addEventListener('click', function() {
    const questionInput = document.getElementById('question-input');
    const question = questionInput.value.trim(); // Ottieni il testo della domanda

    if (question) {
        // Se c'è del testo, riproduci un audio casuale
        playRandomAudio();
        questionInput.value = ''; // Resetta il campo di input
    } else {
        alert('Per favore, inserisci una domanda!');
    }
});

// Event listener per il pulsante "Special Bonus"
document.getElementById('bonus-button').addEventListener('click', playBonusTrack);

// Aggiunta dell'evento "Enter" per inviare la domanda
document.getElementById('question-input').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault(); // Previene l'azione predefinita
        document.getElementById('send-button').click(); // Simula il click del pulsante "Invia"
    }
});
